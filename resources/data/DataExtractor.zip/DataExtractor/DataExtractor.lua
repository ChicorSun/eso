--[[
    Scan for game data and save to savedvars, on demand.
    Data available: Skills, Item Sets, Furniture Items, Recipes.
    Uses layered callbacks to reduce CPU usage (freezes or crashes.)
--]]

local DataExtractorDetails = {
    name            = "DataExtractor",          -- Matches folder and Manifest file names.
    author          = "phuein",
    color           = "DDFFEE",                 -- Used in menu titles and so on.
    menuName        = "Data Extractor",         -- A UNIQUE identifier for menu object.
    -- Default settings.
    savedVariables = {
        FirstLoad = true,                       -- First time the addon is loaded ever.
        -- Scraping categories. TODO
        scrapeSkills = true,
        scrapeItems = true,
        scrapeAchievs = true,
        -- Scraping sub-categories. TODO
        scrapeSets = true,
        scrapeFurniture = true,
        scrapeRecipes = true,
        -- Saved data. NOTE Content length may be long!
        dataSkills = {},
        dataItems = {
            Sets = {},
            Furniture = {},
            CollectibleFurniture = {},
            Recipes = {},
        },
        dataAchievs = {},
        dataStyles = {},
    },
    -- Options.
    itemScanLimit       = 500000,               -- How many itemIDs to scan through. NOTE Max is probably around 200k.
    -- Data.
    dataSkills      = {},                       -- ... skills.
    dataSets        = {},                       -- Holds references to all item sets.
    dataFurniture   = {},                       -- ... furniture.
    dataCollectibleFurniture = {},              -- ... furniture collectibles.
    dataRecipes     = {},                       -- ... recipes.
    dataAchievs     = {},                       -- ... achievements.
    dataStyles      = {},                       -- ... item styles.
    -- Counters.
    dataSkillLinesCounter = 0,
    dataSkillsCounter = 0,

    dataSetsCounter = 0,
    dataFurnitureCounter = 0,
    dataRecipesCounter = 0,

    dataAchievsCounter = 0,
    dataAchievsCatCounter = 0,
    dataAchievsSubcatCounter = 0,

    dataStylesCounter = 0,
    -- Tracking.
    scrapingSkills = false,                     -- Avoid running a scraper more than once at a time.
    scrapingItems = false,
    scrapingAchievs = false,
    scrapingStyles = false,
    -- Track skills async.
    currentType = nil,
    currentLine = nil,
    currentSkill = nil,
    -- Slash commands. Lowercase! Slash!
    slashSkills = '/scrapeskills',
    slashItems = '/scrapeitems',
    slashAchievs = '/scrapeachievs',
    slashStyles = '/scrapestyles',

    slashSave = '/scrapesave',
}

-- Add to global variable.
for k, v in pairs(DataExtractorDetails) do
    DataExtractor[k] = v
end

-- Wraps text with a color.
function DataExtractor.Colorize(text, color)
    -- Default to addon's .color.
    if not color then color = DataExtractor.color end

    text = string.format('|c%s%s|r', color, text)

    return text
end

-- Saved the scraped data from all tables into savedvars,
-- and commits a /reloadui to force save to file.
local function SaveData()
    -- Update savedvars.
    DataExtractor.savedVariables.dataSkills = DataExtractor.dataSkills

    DataExtractor.savedVariables.dataItems.Sets = DataExtractor.dataSets
    DataExtractor.savedVariables.dataItems.Furniture = DataExtractor.dataFurniture
    DataExtractor.savedVariables.dataItems.CollectibleFurniture = DataExtractor.dataCollectibleFurniture
    DataExtractor.savedVariables.dataItems.Recipes = DataExtractor.dataRecipes

    DataExtractor.savedVariables.dataAchievs = DataExtractor.dataAchievs

    ReloadUI("ingame")
end

-- Only show the loading message on first load ever.
function DataExtractor.Activated(e)
    EVENT_MANAGER:UnregisterForEvent(DataExtractor.name, EVENT_PLAYER_ACTIVATED)

    if DataExtractor.savedVariables.FirstLoad then
        DataExtractor.savedVariables.FirstLoad = false
    end
end
-- When player is ready, after everything has been loaded.
EVENT_MANAGER:RegisterForEvent(DataExtractor.name, EVENT_PLAYER_ACTIVATED, DataExtractor.Activated)

function DataExtractor.OnAddOnLoaded(event, addonName)
    if addonName ~= DataExtractor.name then return end
    EVENT_MANAGER:UnregisterForEvent(DataExtractor.name, EVENT_ADD_ON_LOADED)

    DataExtractor.savedVariables = ZO_SavedVars:NewAccountWide("DataExtractorSavedVariables", 1, nil, DataExtractor.savedVariables)

    -- Settings menu in Settings.lua.
    -- DataExtractor.LoadSettings()

    SLASH_COMMANDS[DataExtractor.slashSkills] = DataExtractor.GetAllSkills
    SLASH_COMMANDS[DataExtractor.slashItems] = DataExtractor.GetAllItems
    SLASH_COMMANDS[DataExtractor.slashAchievs] = DataExtractor.GetAllAchievs
    SLASH_COMMANDS[DataExtractor.slashStyles] = DataExtractor.GetAllStyles

    SLASH_COMMANDS[DataExtractor.slashSave] = SaveData
end
-- When any addon is loaded, but before UI (Chat) is loaded.
EVENT_MANAGER:RegisterForEvent(DataExtractor.name, EVENT_ADD_ON_LOADED, DataExtractor.OnAddOnLoaded)