-- Initialize the global variable for all modules to access.

DataExtractor = {}