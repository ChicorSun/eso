-- Updates the callbacks to the next: skill, line, type, or done.
local function UpdateSkillsPosition(i, j, line, k, skillsLimit, linesLimit)
    -- Finished all skills for this line! Catches empty lines.
    if k == skillsLimit or k == -1 then
        -- Finished all skills of all lines of type! Next type. Catches empty types.
        if j == linesLimit or j == -1 then
            -- Finished all skills of all lines of all types! Complete.
            if i == SKILL_TYPE_MAX_VALUE then
                -- Print summary.
                d(
                    string.format(
                        '|cFFFFFFDataExtractor:|r Finished! Types: %s Lines: %s Skills: %s. (Use %s to save the data!)',
                        SKILL_TYPE_MAX_VALUE, DataExtractor.dataSkillLinesCounter, DataExtractor.dataSkillsCounter,
                        DataExtractor.slashSave
                    )
                )
                -- Update tracker.
                DataExtractor.scrapingSkills = false
            else
                -- d('finished type ' .. DataExtractor['currentType'])
                DataExtractor.currentType = DataExtractor.currentType + 1
            end
        else
            -- Next line.
            -- d('finished line ' .. DataExtractor['currentLine'])
            DataExtractor.currentLine = DataExtractor.currentLine + 1
        end
    else
        DataExtractor.currentSkill = DataExtractor.currentSkill + 1
    end
end

-- Get a skill.
local function AddSkill(i, j, line, k, skillsLimit, linesLimit)
    -- Delay until ready for call.
    if DataExtractor.currentSkill ~= k then
        -- Don't keep waiting if moved to next type or line.
        if DataExtractor.currentType == i and DataExtractor.currentLine == j then
            zo_callLater(function() AddSkill(i, j, line, k, skillsLimit, linesLimit) end, 100)
        end
        return
    end

    -- d('adding skill ' .. k)

    local skills = line.skills -- Reference
    skills[k] = {}
    local skill = skills[k] -- Reference

    -- Base skill, only. Below has passive upgrades and active morphs.
    local name, icon, earnedRank, passive, ultimate, purchased, progressionIndex, rank = GetSkillAbilityInfo(i, j, k)

    -- Only skills with morphs have this.
    local pid = GetProgressionSkillProgressionId(i, j, k)

    if pid == 0 then
        -- No morphs, such as passive skills.
        local abilityId = GetSkillAbilityId(i, j, k, false)

        skill.name = zo_strformat(SI_ABILITY_NAME, name)

        skill.id = abilityId
        local aid = skill.id -- Reference.

        skill.description = GetAbilityDescription(aid, MAX_RANKS_PER_ABILITY)

        skill.icon = icon
        skill.passive = passive
        skill.ultimate = ultimate

        -- Same property name for consistency. With passives this means the Skill Level to unlock.
        skill.earnedRank = earnedRank

        skill.cost, skill.resource = GetAbilityCost(aid, MAX_RANKS_PER_ABILITY)
        skill.duration = GetAbilityDuration(aid, MAX_RANKS_PER_ABILITY)
        skill.radius = GetAbilityRadius(aid, MAX_RANKS_PER_ABILITY)
        skill.minRange, skill.maxRange = GetAbilityRange(aid, MAX_RANKS_PER_ABILITY)
        skill.isChanneled, skill.castTime, skill.channelTime = GetAbilityCastInfo(aid, MAX_RANKS_PER_ABILITY)
        skill.isTank, skill.isHealer, skill.isDamage = GetAbilityRoles(aid)
        skill.target = GetAbilityTargetDescription(aid, MAX_RANKS_PER_ABILITY)

        -- Get upgrades for passives.
        if passive then
            local mapped = SKILLS_DATA_MANAGER.abilityIdToProgressionDataMap[aid]
            local skillData = mapped.skillData
            -- Holds all the skill levels.
            local skillProgressions = skillData.skillProgressions

            local upgrades = GetNumPassiveSkillRanks(i, j, k)
            -- Get all further upgrades.
            for x = 2, upgrades do
                skill[x] = {}
                local s = skill[x] -- Reference.

                s.id = skillProgressions[x].abilityId
                s.name = zo_strformat(SI_ABILITY_NAME, GetAbilityName(s.id))

                s.description = GetAbilityDescription(s.id)

                -- Same property name for consistency. With passives this means the Skill Level to unlock.
                s.earnedRank = skillProgressions[x].lineRankNeededToUnlock

                s.cost, s.resource = GetAbilityCost(aid, MAX_RANKS_PER_ABILITY)
                s.duration = GetAbilityDuration(aid, MAX_RANKS_PER_ABILITY)
                s.radius = GetAbilityRadius(aid, MAX_RANKS_PER_ABILITY)
                s.minRange, s.maxRange = GetAbilityRange(aid, MAX_RANKS_PER_ABILITY)
                s.isChanneled, s.castTime, s.channelTime = GetAbilityCastInfo(aid, MAX_RANKS_PER_ABILITY)
                s.isTank, s.isHealer, s.isDamage = GetAbilityRoles(aid)
                s.target = GetAbilityTargetDescription(aid, MAX_RANKS_PER_ABILITY)

                s.parentAbilityId = skill.id
            end
        end
    else
        -- Skills with morphs. Ultimates and fighting skills.
        -- Base and two morphs: 0, 1, 2.
        for x = MORPH_SLOT_MIN_VALUE, MORPH_SLOT_MAX_VALUE do
            local s
            if x == MORPH_SLOT_MIN_VALUE then
                -- Base keeps data in skill table.
                s = skill
            else
                -- Morphs keep data in sub-tables.
                skill[x] = {}
                s = skill[x]
            end

            s.id = GetProgressionSkillMorphSlotAbilityId(pid, x)
            local aid = s.id -- Reference.

            s.name = zo_strformat(SI_ABILITY_NAME, GetAbilityName(aid))

            s.description = GetAbilityDescription(aid, MAX_RANKS_PER_ABILITY)

            s.icon = GetAbilityIcon(aid)
            s.passive = false
            s.ultimate = ultimate

            s.earnedRank = earnedRank -- Only applies to base.
            s.cost, s.resource = GetAbilityCost(aid, MAX_RANKS_PER_ABILITY)
            s.duration = GetAbilityDuration(aid, MAX_RANKS_PER_ABILITY)
            s.radius = GetAbilityRadius(aid, MAX_RANKS_PER_ABILITY)
            s.minRange, s.maxRange = GetAbilityRange(aid, MAX_RANKS_PER_ABILITY)
            s.isChanneled, s.castTime, s.channelTime = GetAbilityCastInfo(aid, MAX_RANKS_PER_ABILITY)
            s.isTank, s.isHealer, s.isDamage = GetAbilityRoles(aid)
            s.target = GetAbilityTargetDescription(aid, MAX_RANKS_PER_ABILITY)

            if x > MORPH_SLOT_MIN_VALUE then
                -- For morphs.
                s.parentAbilityId = skill.id
                s.newEffect = GetAbilityNewEffectLines(aid)
            end
        end
    end

    DataExtractor.dataSkillsCounter = DataExtractor.dataSkillsCounter + 1

    UpdateSkillsPosition(i, j, line, k, skillsLimit, linesLimit)
end

-- Get a skill line, and continue to get its skills.
local function AddLine(data, i, j, linesLimit)
    -- Delay until ready for call.
    if DataExtractor.currentLine ~= j then
        -- Don't keep waiting if moved to next type.
        if DataExtractor.currentType == i then
            zo_callLater(function() AddLine(data, i, j, linesLimit) end, 200)
        end
        return
    end

    -- d('adding line ' .. j)

    local name, rank, unlocked, notid, a, unlock, b, c = GetSkillLineInfo(i, j)

    data[j] = {}
    local line = data[j] -- Reference.

    line.skills = {} -- Will hold all skills in line.

    line.name = name
    -- line.rank = rank
    -- line.unlocked = unlocked
    line.id = notid
    -- line.unlock = unlock
    -- line.a = a
    -- line.b = b
    -- line.c = b

    DataExtractor.dataSkillLinesCounter = DataExtractor.dataSkillLinesCounter + 1

    -- Get all skills for line.
    local skillsLimit = GetNumSkillAbilities(i, j)
    DataExtractor.currentSkill = 1

    -- No skills in line.
    if skillsLimit == 0 then
        -- Make it finish the iteration.
        UpdateSkillsPosition(i, j, line, -1)
        return
    end

    for k = 1, skillsLimit do
        AddSkill(i, j, line, k, skillsLimit, linesLimit)
    end
end

-- Get all skill lines for line type.
-- Continues to getting skills for each line.
local function AddType(i)
    -- Delay until ready for call.
    if DataExtractor.currentType ~= i then
        zo_callLater(function() AddType(i) end, 500)
        return
    end

    -- d('doing type ' .. i)

    local typeName = GetString("SI_SKILLTYPE", i)

    -- Empty type. Next!
    if typeName == '' then
        DataExtractor.currentType = DataExtractor.currentType + 1
        return
    end

    DataExtractor.dataSkills[i] = {}
    local data = DataExtractor.dataSkills[i]

    data.name = typeName

    -- Get all skill lines for type.
    local linesLimit = GetNumSkillLines(i)
    DataExtractor.currentLine = 1

    -- No lines in type.
    if linesLimit == 0 then
        -- Finish the iteration.
        UpdateSkillsPosition(i, -1, nil, -1)
        return
    end

    for j = 1, linesLimit do
        AddLine(data, i, j, linesLimit)
    end
end

-- Scrapes all the skills in the game.
function DataExtractor.GetAllSkills()
    -- Don't run twice.
    if DataExtractor.scrapingSkills == true then
        d('|cFFFFFFDataExtractor:|r Skill scraper is already running!')
        return
    end
    -- Track.
    DataExtractor.scrapingSkills = true

    d('|cFFFFFFDataExtractor:|r Gathering skills data, please wait...')

    -- Gets all types. Each type gets all lines. Each line gets all skills.
    DataExtractor.currentType = SKILL_TYPE_MIN_VALUE
    for i = SKILL_TYPE_MIN_VALUE, SKILL_TYPE_MAX_VALUE do
        AddType(i)
    end
end