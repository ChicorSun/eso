

-- Scrapes all the item styles in the game.
function DataExtractor.GetAllStyles()
    -- Don't run twice.
    if DataExtractor.scrapingStyles == true then
        d('|cFFFFFFDataExtractor:|r Styles scraper is already running!')
        return
    end
    -- Track.
    DataExtractor.scrapingStyles = true

    d(string.format('|cFFFFFFDataExtractor:|r Gathering styles data, please wait...'))

    -- Styles.
    for i = 1, GetNumValidItemStyles() do
        local vId = GetValidItemStyleId(i)
        if vId > 0 then
            local data = DataExtractor.dataStyles
            data[vId] = {}
            local style = data[vId]

            local styleName = GetItemStyleName(vId)
            local styleItemLink = GetItemStyleMaterialLink(vId)
            local icon, sellPrice, meetsUsageRequirement = GetItemLinkInfo(styleItemLink)

            style.id = vId
            style.name = styleName
            style.icon = icon

            DataExtractor.dataStylesCounter = DataExtractor.dataStylesCounter + 1
        end
    end

    d(
        string.format(
            '|cFFFFFFDataExtractor:|r Finished! Total Item Styles: %s. (Use %s to save the data!)',
            DataExtractor.dataStylesCounter, DataExtractor.slashSave
        )
    )
    -- Update tracker.
    DataExtractor.scrapingStyles = false
end