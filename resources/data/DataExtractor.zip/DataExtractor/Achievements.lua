-- Returns the achievements table without any 0 values.
local function CleanupAchievs(ids)
    local t = {}
    for i = 1, #ids do
        if ids[i] ~= 0 then
            table.insert(t, ids[i])
        end
    end
    return t
end

-- Get the achievment's rewards and add them to its table.
local function AddAchievRewards(id, t)
    -- get item reward
    local hasRewardItem, itemName, iconTextureName, quality = GetAchievementRewardItem(id)
    if hasRewardItem then
        t.item = {}
        local item = t.item

        item.name = itemName
        item.icon = iconTextureName
        item.quality = quality
    end

    -- get title reward
    local hasRewardTitle, titleName = GetAchievementRewardTitle(id)
    if hasRewardTitle then
        t.title = {}
        local title = t.title

        title.name = titleName
    end

    -- get dye reward
    local hasRewardDye, dyeId = GetAchievementRewardDye(id)
    if hasRewardDye then
        t.dye = {}
        local dye = t.dye

        dye.id = dyeId

        local dyeName, known, rarity, hueCategory, achievementId, r, g, b, sortKey = GetDyeInfoById(dyeId)

        dye.name = dyeName
        dye.rarity = rarity
        -- dye.hue = hueCategory
        dye.r = r
        dye.g = g
        dye.b = b
        -- dye.sortKey = sortKey
    end

    -- get collectible reward
    local hasRewardCollectible, collectibleId = GetAchievementRewardCollectible(id)
    if hasRewardCollectible then
        t.collectible = {}
        local collectible = t.collectible

        collectible.id = collectibleId

        local collectibleData = ZO_COLLECTIBLE_DATA_MANAGER:GetCollectibleDataById(collectibleId)

        collectible.name = collectibleData:GetFormattedName()
        collectible.prefix = zo_strformat(SI_ACHIEVEMENTS_COLLECTIBLE_CATEGORY, collectibleData:GetCategoryTypeDisplayName())
    end
end

-- Add achievements to the database.
local function AddAchievs(i, j, subCategoryName)
    -- ZO_GetAchievementIds(categoryIndex, subcategoryIndex, numAchievements, considerSearchResults)
    local idsRaw = ZO_GetAchievementIds(i, j, 100, false)

    local ids = CleanupAchievs(idsRaw)

    -- No achievements in subcategory. NOTE The General subcategory check does this.
    if #ids == 0 then return end

    DataExtractor.dataAchievsSubcatCounter = DataExtractor.dataAchievsSubcatCounter + 1

    -- d(ids)
    -- d(#ids .. ' ' .. subCategoryName)

    -- Treat the General subcategory as id 0.
    if j == nil then j = 0 end

    local data = DataExtractor.dataAchievs

    data[i][j] = {} -- Subcategory.
    local subcat = data[i][j]

    subcat.name = subCategoryName

    for k = 1, #ids do
        local id = ids[k]

        -- If there's an achiev line, find the last one to represent the achiev in the database.
        local nextId = GetFirstAchievementInLine(id)

        local counter = 100 -- DEBUG Safety measure against code errors.
        local lastId = id
        while nextId ~= 0 and counter > 0 do
            -- Last id found, repesenting the achiev in database.
            lastId = nextId

            nextId = GetNextAchievementInLine(nextId)

            -- DEBUG.
            counter = counter - 1
            if counter <= 0 then d('DataExtractor: Bug! Overload in AddAchievs() 1st.') end
        end

        -- Override the id with last achiev in line.
        id = lastId

        local achievementName, description, points, icon, completed, date, time = GetAchievementInfo(id)

        subcat[id] = {}
        local achiev = subcat[id]

        achiev.category = data[i].name
        achiev.subcategory = subcat.name

        achiev.name = achievementName
        achiev.description = description
        achiev.points = points
        achiev.icon = icon

        local hasReward = GetAchievementNumRewards(id) > 1

        if hasReward then
            achiev.rewards = {}
            AddAchievRewards(id, achiev.rewards)
        end

        -- Objectives needed to accomplish achievement.
        local numCriterion = GetAchievementNumCriteria(id)

        if numCriterion > 1 then
            achiev.criterion = {}
            for m = 1, numCriterion do
                local description, numCompleted, numRequired = GetAchievementCriterion(id, m)
                achiev.criterion[m] = description
            end
        end

        -- Quests needed to achieve final achievement quest.
        local nextId = GetFirstAchievementInLine(id)

        if nextId ~= 0 then
            achiev.line = {}
        end

        local counter = 100 -- DEBUG Safety measure against code errors.
        while nextId ~= 0 and counter > 0 do
            local curId = nextId

            nextId = GetNextAchievementInLine(nextId)

            -- Last id is the main item in the table, so don't add here.
            if nextId ~= 0 then
                achiev.line[curId] = {}
                local ach = achiev.line[curId]

                local achievementName, description, points, icon, completed, date, time = GetAchievementInfo(curId)

                ach.name = achievementName
                ach.description = description
                ach.points = points
                ach.icon = icon

                ach.category = data[i].name
                ach.subcategory = subcat.name

                local hasReward = GetAchievementNumRewards(curId) > 1

                if hasReward then
                    ach.rewards = {}
                    AddAchievRewards(curId, ach.rewards)
                end
            end

            -- DEBUG.
            counter = counter - 1
            if counter <= 0 then d('DataExtractor: Bug! Overload in AddAchievs() 2nd.') end
        end

        -- Only the last in line achievement is counted.
        DataExtractor.dataAchievsCounter = DataExtractor.dataAchievsCounter + 1
    end
end

-- Scrapes all the achievements in the game.
function DataExtractor.GetAllAchievs()
    -- Don't run twice.
    if DataExtractor.scrapingAchievs == true then
        d('|cFFFFFFDataExtractor:|r Achievements scraper is already running!')
        return
    end
    -- Track.
    DataExtractor.scrapingAchievs = true

    d(string.format('|cFFFFFFDataExtractor:|r Gathering achievements data, please wait...'))

    -- Categories.
    for i = 1, 100 do
        local categoryName, numSubCategories, numAchievements, earnedPoints, totalPoints, hidesPoints = GetAchievementCategoryInfo(i)

        if categoryName ~= '' then
            local data = DataExtractor.dataAchievs
            data[i] = {}
            local category = data[i]

            category.name = categoryName
            category.totalpoints = totalPoints
            -- NOTE Don't use numSubCategories and numAchievements! Use the counters, instead.

            DataExtractor.dataAchievsCatCounter = DataExtractor.dataAchievsCatCounter + 1

            -- Subcategories.
            for j = 1, 100 do
                -- Add the General subcategory on the first iteration.
                -- its id is nil - it's a "fake" subcat, officially.
                if j == 1 then
                    local subCategoryName = "General"

                    AddAchievs(i, nil, subCategoryName)
                end

                local subCategoryName, subNumAchievements = GetAchievementSubCategoryInfo(i, j)

                if subCategoryName ~= '' then
                    AddAchievs(i, j, subCategoryName)

                    DataExtractor.dataAchievsSubcatCounter = DataExtractor.dataAchievsSubcatCounter + 1
                end
            end
        end
    end

    d(
        string.format(
            '|cFFFFFFDataExtractor:|r Finished! Total Achievements: %s Categories: %s Subcategories: %s. (Use %s to save the data!)',
            DataExtractor.dataAchievsCounter, DataExtractor.dataAchievsCatCounter, DataExtractor.dataAchievsSubcatCounter,
            DataExtractor.slashSave
        )
    )
    -- Update tracker.
    DataExtractor.scrapingAchievs = false
end