--[[
GetChampionDisciplineId(luaindex disciplineIndex)
  Returns: integer disciplineId

GetChampionDisciplineName(integer disciplineId)
  Returns: string name

GetChampionSkillId(luaindex disciplineIndex, luaindex championSkillIndex)
  Returns: integer championSkillId

GetChampionSkillJumpPoints(integer championSkillId)
  Uses variable returns...
  Returns: integer jumpPoint
  
GetChampionSkillCurrentBonusText(integer championSkillId, integer numPendingPoints)
  Returns: string currentBonus

CanChampionSkillTypeBeSlotted(ChampionSkillType championSkillType)
  Returns: bool isSlottable

GetChampionClusterSkillIds(integer rootChampionSkillId)
  Uses variable returns...
  Returns: integer championSkillIds
]]

function DataExtractor.GetAllCpSkills()
  local T0 = {}
  --cluster CP
  local clusters = {}
  for i = 1, 1000 do
    if GetChampionClusterName(i) ~= "" then
      for k, v in ipairs({GetChampionClusterSkillIds(i)}) do
        clusters[v] = i
      end
    end
  end
  --single CP
  for i = 1, 10 do
    local disciplineId = GetChampionDisciplineId(i)
    if disciplineId > 0 then
      local T1 = {
        ["index"] = i,
        ["id"] = disciplineId,
        ["name"] = GetChampionDisciplineName(disciplineId),
        ["skills"] = {},
      }
      for j = 1, 100 do
        local championSkillId = GetChampionSkillId(i, j)
        if championSkillId > 0 then
          local T2 = {
            ["index"] = j,
            ["id"] = championSkillId,
            ["name"] = GetChampionSkillName(championSkillId),
            ["type"] = GetChampionSkillType(championSkillId),
            ["description"] = GetChampionSkillDescription(championSkillId),
            ["bounsText"] = {},
            ["isSlottable"] = CanChampionSkillTypeBeSlotted(GetChampionSkillType(championSkillId)),
            ["isInCluster"] = clusters[championSkillId] and true or false,
            ["clusterName"] = GetChampionClusterName(clusters[championSkillId]),
          }
          if #{GetChampionSkillJumpPoints(championSkillId)} > 2 then
            for k, v in ipairs({GetChampionSkillJumpPoints(championSkillId)}) do
              T2.bounsText[v] = GetChampionSkillCurrentBonusText(championSkillId, v)
            end
          end
          table.insert(T1.skills, T2)
        end
      end
      table.insert(T0, T1)
    end
  end
  DataExtractor.dataCpSkills = T0
  d('|cFFFFFFDataExtractor:|r 完工! CP技能已抓取 (使用 /scrapesave 指令来保存数据!)')
end