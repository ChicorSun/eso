-- Adds items to the database from given item id that applies to a link object.
-- i - (int) item id.
-- Returns true on success.

local Recipes = {}
local RecipesLinks = {}

local function AddItemFromID(i)
    --Run at first time
    if not Recipes[33526] then 
      for x = 1, 40 do
        for y = 1, 1000 do
          local TargetId = select(8, GetRecipeInfo(x, y))
          if TargetId == 0 then
            break
          else
            Recipes[TargetId] = {x, y}
          end
        end
      end
    end

    -- Textless link.
    -- 364, 50 for max lvl.
    -- 10000 for fully repaired. (2nd from last, might not be necessary.)
    local link = ZO_LinkHandler_CreateLink('', nil, ITEM_LINK_TYPE, i, 364, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

    local itemName = GetItemLinkName(link)

    -- No match, skip.
    if itemName == '' then return end

    -- Only matching for: Sets, Furniture, and Recipes.
    -- Vars will be used below!
    local hasSet, setName, setNumBonuses, setNumEquipped, setMaxEquipped, setID = GetItemLinkSetInfo(link)
    local itemType, specializedItemType = GetItemLinkItemType(link)
    local itemTypeName = GetString("SI_ITEMTYPE", itemType)
    local itemStyle = GetItemLinkItemStyle(link)
    local itemStyleName = GetItemStyleName(itemStyle)
    local itemIcon = GetItemLinkIcon(link)

    -- Format.
    itemName = zo_strformat(SI_TOOLTIP_ITEM_NAME, itemName)

    -- Sets.
    if hasSet then
        local data = DataExtractor.dataSets

        local itemEquipType = GetItemLinkEquipType(link)
        local itemEquipTypeName = GetString("SI_EQUIPTYPE", itemEquipType)

        -- Either armor or weapon.
        local itemTypeSpecificName
        if itemType == ITEMTYPE_ARMOR then
            local armorType = GetItemLinkArmorType(link)
            itemTypeSpecificName = GetString("SI_ARMORTYPE", armorType)
        else
            local weaponType = GetItemLinkWeaponType(link)
            itemTypeSpecificName = GetString("SI_WEAPONTYPE", weaponType)
        end

        -- Set already listed.
        if data[setID] then
            local item = data[setID] -- Reference.
            -- Add item style.
            item.styles[itemTypeName] = item.styles[itemTypeName] or {}
            item.styles[itemTypeName][itemEquipTypeName] = item.styles[itemTypeName][itemEquipTypeName] or {}
            item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName] = {}
            item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName].styleId = itemStyle
            item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName].style = itemStyleName
            item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName].icon = itemIcon
            return
        end

        data[setID] = {}
        local item = data[setID] -- Reference.

        item.id = setID
        item.name = zo_strformat(SI_TOOLTIP_ITEM_NAME, setName)

        -- Add some setInfo by @Chicor ---------
        for k,v in pairs(LibSets.setInfo) do
            if k == item.id then
                local zoneIds = v.zoneIds
                local setType = v.setType
                local zoneNames = ""
                for kk,vv in pairs(zoneIds) do
                    if zoneNames == "" then
                        zoneNames = GetZoneNameById(zoneIds[kk])
                    elseif not string.find(zoneNames, GetZoneNameById(zoneIds[kk])) then
                        zoneNames = zoneNames..","..GetZoneNameById(zoneIds[kk]) 
                    end
                end
                item["type"] = setType
                item["place"] = zoneNames
                break
            end
        end

        local setItemIDs = LibSets.GetSetItemIds(item.id)
        item["itemIDs"] = setItemIDs
        -----------------------------------------

        item.styles = {}

        item.styles[itemTypeName] = {}
        item.styles[itemTypeName][itemEquipTypeName] = {}
        item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName] = {}
        item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName].styleId = itemStyle
        item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName].style = itemStyleName
        item.styles[itemTypeName][itemEquipTypeName][itemTypeSpecificName].icon = itemIcon

        -- Add some setInfo by @Chicor ---------
        -- Get bonuses info.
        item.bonuses = {}
        for j = 1, setNumBonuses do
            local numRequired, bonusDescription = GetItemLinkSetBonusInfo(link, nil, j)
            --item[j+1] = bonusDescription
            item.bonuses[j+1] = bonusDescription
        end
        -----------------------------------------


        DataExtractor.dataSetsCounter = DataExtractor.dataSetsCounter + 1

        return true
    end

    -- Furniture.
    if itemType == ITEMTYPE_FURNISHING then
        local data = DataExtractor.dataFurniture

        data[i] = {}
        local item = data[i] -- Reference.

        item.id = i -- Item ID.
        item.name = itemName

        local quality = GetItemLinkQuality(link)
        quality = GetString("SI_ITEMQUALITY", quality)
        item.quality = quality

        local flavor = GetItemLinkFlavorText(link)
        if flavor ~= '' then
            item.description = flavor
        end

        item.icon = itemIcon

        local dataId = GetItemLinkFurnitureDataId(link)
        item.furnitureId = furnitureId

        -- Category.
        local categoryId, subcategoryId = GetFurnitureDataCategoryInfo(dataId)
        item.category = GetFurnitureCategoryName(categoryId)
        item.subcategory = GetFurnitureCategoryName(subcategoryId)

        -- Tags. "Furnishing Behavior".
        local numTags = GetItemLinkNumItemTags(link)
        local tagStrings = {}
        for j = 1, numTags do
            local tagDescription, tagCategory = GetItemLinkItemTagInfo(link, j)

            if tagDescription ~= '' then
                table.insert(tagStrings, zo_strformat(SI_TOOLTIP_ITEM_TAG_FORMATER, tagDescription))
            end
        end
        if #tagStrings > 0 then
            item.tags = table.concat(tagStrings, ', ')
        end

        DataExtractor.dataFurnitureCounter = DataExtractor.dataFurnitureCounter + 1

        return true
    end
    
    -- Foods.
    if (itemType == ITEMTYPE_DRINK or itemType == ITEMTYPE_FOOD) and IsItemLinkConsumable(link) then
        local item = {
          ["id"] = i,
          ["name"] = itemName,
          ["quality"] = GetString("SI_ITEMQUALITY", GetItemLinkQuality(link)),
          ["icon"] = itemIcon,
          ["itemTypeText"] = itemTypeName,
          ["specializedItemTypeText"] = GetString("SI_SPECIALIZEDITEMTYPE", specializedItemType),
          ["description"] = select(3, GetItemLinkOnUseAbilityInfo(link)),
          ["canBeCrafted"] = Recipes[i] and true or false,
          ["ingredients"] = "",
        }
        DataExtractor.dataFoods[i] = item
        DataExtractor.dataFoodsCounter = DataExtractor.dataFoodsCounter + 1
        return true
    end
    
    -- Recipes.
    if itemType == ITEMTYPE_RECIPE then
        local data = DataExtractor.dataRecipes

        data[i] = {}
        local item = data[i] -- Reference.

        item.id = i
        item.name = itemName

        local quality = GetItemLinkQuality(link)
        quality = GetString("SI_ITEMQUALITY", quality)
        item.quality = quality

        local recipeType = GetItemLinkRecipeCraftingSkillType(link)
        recipeType = GetCraftingSkillName(recipeType)
        item.type = recipeType

        local recipeItemLink = GetItemLinkRecipeResultItemLink(link)
        local hasAbility, abilityHeader, abilityDescription, cooldown, hasScaling, minLevel, maxLevel, isChampionPoints, remainingCooldown = GetItemLinkOnUseAbilityInfo(recipeItemLink)
        if hasAbility then
            item.description = abilityDescription

            if hasScaling then
                local champ = ''
                if isChampionPoints then champ = 'cp' end
                item.scales = string.format('Scales from level %s%s to %s%s.', champ, minLevel, champ, maxLevel)
            end
        end
        
        RecipesLinks[GetItemLinkItemId(recipeItemLink)] = link
        
        -- Ingredients.
        local ingredients = {}
        local numIngredients = GetItemLinkRecipeNumIngredients(link)
        for j = 1, numIngredients do
            local ingredientName, numOwned, numRequired = GetItemLinkRecipeIngredientInfo(link, j)
            table.insert(ingredients, string.format('%s (%s)', ingredientName, numRequired))
        end
        item.ingredients = table.concat(ingredients, ', ')

        -- Skills required.
        local skills = {}
        local numSkillsReq = GetItemLinkRecipeNumTradeskillRequirements(link)
        for j = 1, numSkillsReq do
            local skill, lvl = GetItemLinkRecipeTradeskillRequirement(link, j)

            local skillid = GetTradeskillLevelPassiveAbilityId(skill)
            local skillName = GetAbilityName(skillid)

            table.insert(skills, string.format('%s %s', skillName, lvl))
        end
        item.skills = table.concat(skills, ', ')

        DataExtractor.dataRecipesCounter = DataExtractor.dataRecipesCounter + 1

        return true
    end
end

-- Adds collectibles to the database, if they are used as furniture.
-- i - (int) collectible id.
-- Returns true on success.
local function AddCollectibleFromID(i)
    -- Collectibles - Some are Furniture.
    local collectibleName = GetCollectibleName(i)

    -- No match, skip.
    if collectibleName == '' then return end

    local furnitureId = GetCollectibleFurnitureDataId(i)

    -- Not furniture, skip.
    if furnitureId == 0 then return end

    local collectibleDescription = GetCollectibleDescription(i)

    -- No description, unavailable collectible, skip.
    if collectibleDescription == '' then return end

    local data = DataExtractor.dataCollectibleFurniture

    data[i] = {}
    local item = data[i] -- Reference.

    item.id = i -- Collectible ID.
    item.furnitureId = furnitureId
    item.name = zo_strformat(SI_TOOLTIP_ITEM_NAME, collectibleName) -- Format.

    item.description = collectibleDescription
    item.hint = GetCollectibleHint(i) -- How to get the collectible.
    item.category = GetCollectibleCategoryName(i)
    item.icon = GetCollectibleIcon(i)

    DataExtractor.dataFurnitureCounter = DataExtractor.dataFurnitureCounter + 1

    return true
end

-- Scrapes all the items in the game.
function DataExtractor.GetAllItems()
    -- Don't run twice.
    if DataExtractor.scrapingItems == true then
        d('|cFFFFFFDataExtractor:|r 物品遍历已在进行!')
        return
    end
    -- Track.
    DataExtractor.scrapingItems = true

    -- Iterate over all items in-game.
    local limit = DataExtractor.itemScanLimit

    local chunk = 100               -- Split the load to avoid crashing the game.
    local chunks = limit / chunk    -- How many chunks to process.
    local delay = 20                -- ms delay between chunks.

    for t = 1, chunks do
        zo_callLater(function()
            local x = 1 + (chunk * (t-1))   -- Start.
            local y = chunk * t             -- End.

            for i = x, y do
                AddItemFromID(i)
                AddCollectibleFromID(i)
            end

            -- FINISHED. Last chunk prints summary.
            if t == chunks then
              
                --Food Ingredients.
                for k, v in pairs(DataExtractor.dataFoods) do
                  if v.canBeCrafted then
                    local link = RecipesLinks[k]
                    local ingredients = {}
                    local numIngredients = GetItemLinkRecipeNumIngredients(link)
                    for j = 1, numIngredients do
                      local ingredientName, numOwned, numRequired = GetItemLinkRecipeIngredientInfo(link, j)
                      table.insert(ingredients, string.format('%s (%s)', ingredientName, numRequired))
                    end
                    v.ingredients = table.concat(ingredients, ', ')
                  end
                end
                
                d(
                    string.format(
                        '|cFFFFFFDataExtractor:|r 完工! 总IDs: %s 套装: %s 家具: %s 配方: %s 食物: %s. (使用 %s 指令来保存数据!)',
                        limit, DataExtractor.dataSetsCounter, DataExtractor.dataFurnitureCounter, DataExtractor.dataRecipesCounter, DataExtractor.dataFoodsCounter,
                        DataExtractor.slashSave
                    )
                )
                -- Update tracker.
                DataExtractor.scrapingItems = false
            end
        end, delay * t)
    end
    
    d(string.format('|cFFFFFFDataExtractor:|r 抓取物品数据中, 请等待约 %s 秒...', math.floor((chunks * delay) / 1000)))
end
