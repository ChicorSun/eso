

-- Scrapes all the item styles in the game.
function DataExtractor.GetAllStyles()
    -- Don't run twice.
    if DataExtractor.scrapingStyles == true then
        d('|cFFFFFFDataExtractor:|r 样式遍历已在进行!')
        return
    end
    -- Track.
    DataExtractor.scrapingStyles = true

    d(string.format('|cFFFFFFDataExtractor:|r 抓取样式数据，请等待...'))

    -- Styles.
    for i = 1, GetNumValidItemStyles() do
        local vId = GetValidItemStyleId(i)
        if vId > 0 then
            local data = DataExtractor.dataStyles
            data[vId] = {}
            local style = data[vId]

            local styleName = GetItemStyleName(vId)
            local styleItemLink = GetItemStyleMaterialLink(vId)
            local icon, sellPrice, meetsUsageRequirement = GetItemLinkInfo(styleItemLink)

            style.id = vId
            style.name = styleName
            style.icon = icon

            DataExtractor.dataStylesCounter = DataExtractor.dataStylesCounter + 1
        end
    end

    d(
        string.format(
            '|cFFFFFFDataExtractor:|r 完工! 总样式: %s. (使用 %s 指令来保存数据!)',
            DataExtractor.dataStylesCounter, DataExtractor.slashSave
        )
    )
    -- Update tracker.
    DataExtractor.scrapingStyles = false
end