local function ToLink(Id)
  if not Id then return "" end
  return "|H0:item:"..tostring(Id)..":30:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"
end

local function RealName(Id)
  local link = ToLink(Id)
  return zo_strformat(SI_TOOLTIP_ITEM_NAME, GetItemLinkName(link))
end

local function GetEncode(String)
  local NumString = ""
  for word in string.gmatch(String, "%d+|") do
    NumString = string.gsub(word, "|", "",1)
  end
  return tonumber(NumString)
end

local function GetDescription(link)
  local list = {}
  for i = 1, 10 do
    text = select(2, GetItemLinkTraitOnUseAbilityInfo(link, i))
    if text ~= "" then
      table.insert(list, text)
    else 
      break
    end
  end
  return list
end

--Need all traits unlock and all kinds of materials in bag when run
local Reagents = {
  77587,  --Fleshfly Larva              64
  30148,  --Blue Entoloma               66
  30162,  --Dragonthorn                 66
  30154,  --White Cap                   68
  30159,  --Wormwood                    75
  30155,  --Luminous Russula            79
  77584,  --Spider Egg                  79
  30166,  --Water Hyacinth              81
  30165,  --Nirnroot                    81
  30157,  --Blessed Thistle             82
  30153,  --Namira's Rot                84
  30158,  --Lady's Smock                88
  77585,  --Butterfly Wing              90
  30149,  --Stinkhorn                   94
  30156,  --Imp Stool                   108
  150789, --Dragon's Bile               113
  77590,  --Nightshade                  118
  30151,  --Emetic Russula              124
  30161,  --Corn Flower                 134
  77583,  --Beetle Scuttle              176
  30163,  --Mountain Flower             231
  30160,  --Bugloss                     295
  77589,  --Scrib Jelly                 410
  150672, --Crimson Nirnroot            523
  150670, --Vile Coagulant              626
  77591,  --Mudcrab Chitin              658
  77581,  --Torchbug Thorax             726
  139020, --Clam Gall                   791
  150669, --Chaurus Egg                 825

  30152,  --Violet Coprinus             1019
  30164,  --Columbine                   1651
  139019, --Powdered Mother of Pearl    2016

  150731, --Dragon's Blood              3809
  150671, --Dragon Rheum                7793
}

function DataExtractor.GetAllPotions()
  d("|cFFFFFFDataExtractor:|r 请确保已解锁所有炼金材料的所有词条，且制作背包中存在所有种类的炼金材料")
  local LinkList = {}
  --Record all 2 materiasl potion links
  for a = 1, 34 do
    for b = a + 1 , 34 do
      local Link1 = GetAlchemyResultingItemLink(5, 75365, 5, Reagents[a], 5, Reagents[b])
      LinkList[Link1] = LinkList[Link1] or {}
      table.insert(LinkList[Link1], {RealName(Reagents[a]), RealName(Reagents[b])})
      local Link2 = GetAlchemyResultingItemLink(5, 64501, 5, Reagents[a], 5, Reagents[b])
      LinkList[Link2] = LinkList[Link2] or {}
      table.insert(LinkList[Link2], {RealName(Reagents[a]), RealName(Reagents[b])})
    end
  end
  --Record all 3 materials potion links
  for a = 1, 34 do
    for b = a + 1 , 34 do
      for c = b + 1 , 34 do
        local Link1 = GetAlchemyResultingItemLink(5, 75365, 5, Reagents[a], 5, Reagents[b], 5, Reagents[c])
        LinkList[Link1] = LinkList[Link1] or {}
        table.insert(LinkList[Link1], {RealName(Reagents[a]), RealName(Reagents[b]), RealName(Reagents[c])})
        local Link2 = GetAlchemyResultingItemLink(5, 64501, 5, Reagents[a], 5, Reagents[b], 5, Reagents[c])
        LinkList[Link2] = LinkList[Link2] or {}
        table.insert(LinkList[Link2], {RealName(Reagents[a]), RealName(Reagents[b]), RealName(Reagents[c])})
      end
    end
  end
  --Links to List
  local T0 = {}
  for k, v in pairs(LinkList) do
    local link = k
    local itemType = GetItemLinkItemType(link)
    local item = {
      ["id"] = GetItemLinkItemId(link),
      ["encode"] = GetEncode(link) or 0,
      ["name"] = GetItemLinkName(link),
      ["quality"] = GetString("SI_ITEMQUALITY", GetItemLinkQuality(link)),
      ["icon"] = GetItemLinkIcon(link),
      ["itemTypeText"] = GetString("SI_ITEMTYPE", itemType),
      ["description"] = GetDescription(link),
      ["canBeCrafted"] = true,
      ["recipes"] = v,
    }
    T0[item.id] = T0[item.id] or {}
    T0[item.id][item.encode] = item
  end
  --Other Postions
  for i = 1, DataExtractor.itemScanLimit do
    if not T0[i] then
      local link = ToLink(i)
      local itemType = GetItemLinkItemType(link)
      if IsItemLinkConsumable(link) and (itemType == ITEMTYPE_POTION or itemType == ITEMTYPE_POISON) then
        local item = {
          ["id"] = GetItemLinkItemId(link),
          ["encode"] = GetEncode(link) or 0,
          ["name"] = GetItemLinkName(link),
          ["quality"] = GetString("SI_ITEMQUALITY", GetItemLinkQuality(link)),
          ["icon"] = GetItemLinkIcon(link),
          ["itemTypeText"] = GetString("SI_ITEMTYPE", itemType),
          ["description"] = select(3, GetItemLinkOnUseAbilityInfo(link)),
          ["canBeCrafted"] = false,
        }
        T0[item.id] = T0[item.id] or {}
        T0[item.id][item.encode] = item
      end
    end
  end
  DataExtractor.dataPotions = T0
  d('|cFFFFFFDataExtractor:|r 完工! 药水已抓取 (使用 /scrapesave 指令来保存数据!)')
end