local function SaveData()
    -- Update savedvars.
    DataExtractor.savedVariables.dataSkills = DataExtractor.dataSkills
    DataExtractor.savedVariables.dataCpSkills = DataExtractor.dataCpSkills
    DataExtractor.savedVariables.dataPotions = DataExtractor.dataPotions
    
    DataExtractor.savedVariables.dataItems.Sets = DataExtractor.dataSets
    DataExtractor.savedVariables.dataItems.Foods = DataExtractor.dataFoods
    DataExtractor.savedVariables.dataItems.Furniture = DataExtractor.dataFurniture
    DataExtractor.savedVariables.dataItems.CollectibleFurniture = DataExtractor.dataCollectibleFurniture
    DataExtractor.savedVariables.dataItems.Recipes = DataExtractor.dataRecipes

    DataExtractor.savedVariables.dataAchievs = DataExtractor.dataAchievs

    ReloadUI("ingame")
end

-- Settings menu.
function DataExtractor.LoadSettings()
    local LAM = LibStub("LibAddonMenu-2.0")

    local panelData = {
        type = "panel",
        name = DataExtractor.menuName.." 数据提取器",
        displayName = DataExtractor.Colorize(DataExtractor.menuName),
        author = DataExtractor.Colorize(DataExtractor.author, "AAF0BB"),
        -- version = DataExtractor.Colorize(DataExtractor.version, "AA00FF"),
        -- slashCommand = "/dataextractor",
        registerForRefresh = true,
        registerForDefaults = true,
    }
    LAM:RegisterAddonPanel(DataExtractor.menuName, panelData)

    local optionsTable = {
      {
        type = "button",
        name = "以下所有",
        tooltip = "将会产生一定卡顿",
        func = function() 
          DataExtractor.GetAllSkills() 
          DataExtractor.GetAllCpSkills()
          DataExtractor.GetAllItems()
          DataExtractor.GetAllPotions()
          DataExtractor.GetAllAchievs()
          DataExtractor.GetAllStyles()
        end,
        width = "half",
      },
      {
        type = "button",
        name = "技能",
        func = function() DataExtractor.GetAllSkills() end,
        width = "half",
      },
      {
        type = "button",
        name = "CP技能",
        func = function() DataExtractor.GetAllCpSkills() end,
        width = "half",
      },
      {
        type = "button",
        name = "物品",
        tooltip = "包含 套装、家具、食物、配方",
        func = function() DataExtractor.GetAllItems() end,
        width = "half",
      },
      {
        type = "button",
        name = "药水",
        func = function() DataExtractor.GetAllPotions() end,
        width = "half",
      },
      {
        type = "button",
        name = "成就",
        func = function() DataExtractor.GetAllAchievs() end,
        width = "half",
      },
      {
        type = "button",
        name = "样式",
        func = function() DataExtractor.GetAllStyles() end,
        width = "half",
      },
      {
        type = "divider",
      },
      {
        type = "button",
        name = "中英文切换",
        func = function()
          if GetCVar("language.2") == "zh" then
            SetCVar("language.2","en")
          else
            SetCVar("language.2","zh")
          end
        end,
        warning = "将会自动重载UI",
        width = "half",
      },
      {
        type = "button",
        name = "保存所有数据",
        func = function() SaveData() end,
        width = "half",
        warning = "将会自动重载UI",
      },
    }
    LAM:RegisterOptionControls(DataExtractor.menuName, optionsTable)
end